package concurrent;

public class CP    {
	public static final Object obj = new Object();
	public static void main(String[] args) {
       new Thread( new Producer2()).start();
       new Thread( new Consumer2()).start();
      
}
}
class Consumer2 implements Runnable {
    @Override
    public synchronized void run() {
           int count = 20;
           while(count > 0) {
                synchronized (CP.obj) {
                    System. out.print( "B");
                    count --;
                    CP.obj.notify(); // 主动释放对象锁
                    
                     try {
                          CP.obj.wait();
                          try { //加延时方便看打印信息
                              Thread. sleep(91L);
                        } catch (InterruptedException e) {
                               // TODO Auto-generated catch block
                              e.printStackTrace();
                        }
                    } catch (InterruptedException e) {
                          e.printStackTrace();
                    }
               }
               
          }
    }
}

class Producer2 implements Runnable {

    @Override
    public void run() {
           int count = 20;
           while(count > 0) {
                synchronized (CP.obj) {
                    System. out.print( "A");
                    count --;
                    CP.obj.notify();
                     try {
                          CP.obj.wait();
                          try { //加延时方便看打印信息
                              Thread. sleep(91L);
                        } catch (InterruptedException e) {
                               // TODO Auto-generated catch block
                              e.printStackTrace();
                        }
                    } catch (InterruptedException e) {
                           // TODO Auto-generated catch block
                          e.printStackTrace();
                    }
               }
               
          }

    }

}


