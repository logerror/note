# -*- coding:utf-8 -*-
#author:anke
#the module is used to standardlize the kvm host
#usage

import sys
import ansible.playbook
from ansible import callbacks
from ansible import utils
import libvirt
from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from kvm_command_platform.db_table_define import HostInfo
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from libvirt import libvirtError

#用来定义初始化过程中结果，如过程出现失败，则result_count++


#初始化playbook中变量
stats = callbacks.AggregateStats()
playbook_cb = callbacks.PlaybookCallbacks(verbose=utils.VERBOSITY)
runner_cb = callbacks.PlaybookRunnerCallbacks(stats, verbose=utils.VERBOSITY)

#初始化db连接串信息
db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)
db_session = session()

#playbook执行函数
def execute(play,ip,params):
  pb = ansible.playbook.PlayBook(
    playbook=play,
    host_list=ip,
    stats=stats,
    callbacks=playbook_cb,
    runner_callbacks=runner_cb,
    check=False,
    extra_vars=params,
    remote_user='sflog',
    remote_pass=None,
    become=True,
    become_method='su',
    become_user='sfroot',
    become_pass='Kendy930'

  )
  print pb
  return pb.run()

#创建kvm pool函数
def pool_create(remote_ip,result):
    xml = """
                    <pool type='dir'>
       <name>image</name>
       <capacity unit='bytes'>0</capacity>
       <allocation unit='bytes'>0</allocation>
       <available unit='bytes'>0</available>
       <source>
       </source>
       <target>
         <path>/app/image</path>
       </target>
    </pool>"""

    try:
        conn = libvirt.open('qemu+tcp://webvirtmgr@'+remote_ip+'/system')
        conn.storagePoolDefineXML(xml, 0)
        stg = conn.storagePoolLookupByName('image')
        stg.create(0)
        stg.setAutostart(1)
    except libvirtError, e:
        result = result + 1
        return result
    conn.close()
    return result

def host_std(ip,sn,env,area,pool=1):
    #用来收集运行过程结果,失败则count+1
    result_count = 0

    #构造host信息, 用于db查询
    host_add = HostInfo(host_ip=ip, env=env, net_area=area, host_pool=pool, sn=sn)

    #查找db中host表是否有重复数据
    ip_in_hostinfo = ''
    for db_host_info in db_session.query(HostInfo).filter(HostInfo.host_ip == ip):
        ip_in_hostinfo = db_host_info.host_ip
    if ip_in_hostinfo != '':
        return "host "+ip_in_hostinfo+" is already in db"

    #构造execute函数入参
    url='/home/sflog/host_std_info/host_std.yaml'
    host_dict={"hosts":ip}
    ip1 = [ip]

    #运行playbook
    res = execute(url,ip1,host_dict)

    #判断playbook执行结果
    print res
    failures = res[ip]['failures']
    unreachable = res[ip]['unreachable']
    result_count = result_count + failures + unreachable

    if result_count > 0:
        db_session.commit()
        db_session.close()
        return "failure,playbook occured errors!,host standardlized failed"


    #执行pool_create函数,并收集执行结果
    else:
        result_count = pool_create(ip,result_count)

        #如果全部执行成功则将host信息入库
        if result_count>0:
            db_session.commit()
            db_session.close()
            return 'failure,'+"pool create failed,host standardlized failed"
        else:
            db_session.add(host_add)
            db_session.commit()
            db_session.close()
            return 'success,'+ip+" standardlize is done,and added to db"



if __name__=='__main__':
    host_std(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4])