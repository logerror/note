# -*- coding:utf-8 -*-
# __author__ = '郭思远'

import ansible.runner
import logging
from kvm_command_platform.setting import AB_REMOTE_USER, AB_REMOTE_SU_USER, AB_REMOTE_SU_USER_PASSWD, AB_REMOTE_USER_PASSWD


# 使用ansible做命令下发并返回结果
def ansible_command_get(host, command):
    # 每次md5执行命令行成功日志记录
    logger_command_return = logging.getLogger('log_ansible_command_return')
    logger_command_return.setLevel(logging.DEBUG)
    fh_command_return = logging.FileHandler('/root/kvm_command_platform/log_ansible_command_return.log')
    fh_command_return.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
    fh_command_return.setFormatter(formatter)

    # 每次md5执行命令行失败日志记录
    logger_command_return_error = logging.getLogger('log_ansible_command_return_error')
    logger_command_return_error.setLevel(logging.DEBUG)
    fh_command_return_error = logging.FileHandler('/root/kvm_command_platform/log_ansible_command_return_error.log')
    fh_command_return_error.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
    fh_command_return_error.setFormatter(formatter)

    ar = ansible.runner.Runner(pattern='*', forks=10, timeout=1800,
                               host_list=host, module_name='shell',
                               module_args=command,
                               remote_user=AB_REMOTE_USER,
                               remote_pass=AB_REMOTE_USER_PASSWD,
                               become=True,
                               become_method='su',
                               become_user=AB_REMOTE_SU_USER,
                               become_pass=AB_REMOTE_SU_USER_PASSWD
                               ).run()
    if ar['contacted'] == '{}':
        logger_command_return_error.addHandler(fh_command_return_error)
        logger_command_return_error.info(ar)
        logger_command_return_error.removeHandler(fh_command_return_error)
        return 1
    elif 'failed' in ar['contacted'][host[0]]:
        logger_command_return_error.addHandler(fh_command_return_error)
        logger_command_return_error.info(ar)
        logger_command_return_error.removeHandler(fh_command_return_error)
        return 2
    else:
        md5 = ar['contacted']
        logger_command_return.addHandler(fh_command_return)
        logger_command_return.info(md5)
        logger_command_return.removeHandler(fh_command_return)
        return md5
