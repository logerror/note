package concurrent;

import java.util.concurrent.TimeUnit;

public class Interrupted {

	/*
	 * sleep's interrupt status is :false
	busy's interrupt status is :true
	java.lang.InterruptedException: sleep interrupted
	at java.lang.Thread.sleep(Native Method)
	at java.lang.Thread.sleep(Thread.java:340)
	at java.util.concurrent.TimeUnit.sleep(TimeUnit.java:386)
	at com.sf.vishnu.arrange.common.Interrupted$SleepThread.run(Interrupted.java:28)
	at java.lang.Thread.run(Thread.java:745)
	 */
	public static void main(String[] args) throws InterruptedException {
		Thread sleep = new Thread(new SleepThread(), "sleep-thread");
		Thread busy = new Thread(new BusyThread(), "busy-thread");
		sleep.setDaemon(true);
		busy.setDaemon(true);
		sleep.start();
		busy.start();
		TimeUnit.SECONDS.sleep(5);
		sleep.interrupt();
		busy.interrupt();
		System.out.println("sleep's interrupt status is :"+sleep.isInterrupted());
		System.out.println("busy's interrupt status is :"+busy.isInterrupted());
		TimeUnit.SECONDS.sleep(2);
	}

	static class SleepThread implements Runnable{
		
		@Override
		public void run(){
			while(true){
				try {
					TimeUnit.SECONDS.sleep(10);
					/**
					 * Causes the currently executing thread to sleep (temporarily cease execution) 
						for the specified number of milliseconds, subject to the precision and accuracy of system timers and schedulers. 
						The thread does not lose ownership of any monitors.
						if any thread has interrupted the current thread. 
						The interrupted status of the current thread is cleared when this exception is thrown.	
					 */	
				} catch (InterruptedException e) {
					/**
					 *Thrown when a thread is waiting, sleeping, or otherwise occupied, 
					 *and the thread is interrupted, either before or during the activity. 
					 *Occasionally a method may wish to test whether the current thread has been interrupted, 
					 *and if so, to immediately throw this exception. 
					 *The following code can be used to achieve this effect:  
					 if (Thread.interrupted())  // Clears interrupted status!
     				throw new InterruptedException();
					 */  
					e.printStackTrace();
				} 
			}
		}
	}
	
	static class BusyThread implements Runnable{
		@Override
		public void run(){
			while(true){
				// keep busy and do not quit
			}
		}
	}
}
