package concurrent;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class ConsumeProducer {
	public static AtomicInteger num = new AtomicInteger(10);
	public static volatile boolean flag = true;
	public static void main(String[] args) {
        Lock lock = new ReentrantLock();
        Consumer consumer = new Consumer(lock,num,flag);
        Producer producer = new Producer(lock,num,flag);
        
         new Thread(consumer).start();
         new Thread( producer).start();
        
  }
	
}

 class Consumer implements Runnable {
	 
    private Lock lock;
    public Consumer(Lock lock) {
           this. lock = lock;
    }
    public Consumer(Lock lock, AtomicInteger count, boolean flag) {
        this. lock = lock;
        this.count=count;
        this.flag=flag;
    }
    private boolean flag;
    private AtomicInteger count ;
    @Override
    public void run() {
           // TODO Auto-generated method stub
           while( count.intValue()>0 &&ConsumeProducer.flag) {
                try {
                     lock.lock();
                     ConsumeProducer.flag=false;
                   count.decrementAndGet();
                    System. out.print( "B");
               } finally {
                     lock.unlock(); //主动释放锁
                     try { //加延时方便看打印信息
                          Thread. sleep(91L);
                    } catch (InterruptedException e) {
                           // TODO Auto-generated catch block
                          e.printStackTrace();
                    }
               }
          }

    }

}

 class Producer implements Runnable{

    private Lock lock;
    public Producer(Lock lock) {
           this. lock = lock;
    }
    public Producer(Lock lock, AtomicInteger count, boolean flag) {
        this. lock = lock;
        this.count=count;
        this.flag=flag;
    }
    private boolean flag;
    private AtomicInteger count ;
    
    @Override
    public void run() {
           // TODO Auto-generated method stub
           while (count.intValue() > 0 && !ConsumeProducer.flag ) {
                try {
                     lock.lock();
                     ConsumeProducer.flag=true;
                    count.decrementAndGet();
                    System. out.print( "A");
               } finally {
                     lock.unlock();
                     try {
                          Thread. sleep(90L);
                    } catch (InterruptedException e) {
                           // TODO Auto-generated catch block
                          e.printStackTrace();
                    }
               }
          }
    }
}
