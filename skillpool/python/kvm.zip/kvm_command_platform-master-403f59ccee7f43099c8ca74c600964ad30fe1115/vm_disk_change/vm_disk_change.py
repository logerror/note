# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
from kvm_command_platform.ansible_operation import ansible_command_get
import time
from libvirt import libvirtError
import libvirt_qemu
from kvm_command_platform import log_helper
import logging

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_disk_change(vm_name, directory, add_size):
    log_handler = log_helper.init_log('vm_disk_change')
    vm_in_host = ''
    retry_conn_libvirt = 0
    succeed_to_conn_libvirt = False
    vm_status = 0

    # if not vdisk.isdigit():
    #  return 'error input ' + vdisk

    if not add_size.isdigit():
        return 'error input disk add size: ' + add_size
    elif int(add_size) <= 0:
        return 'error input disk add size: ' + add_size

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
    db_session.commit()
    db_session.close()

    if vm_in_host == '':
        return 'can not found vm ' + vm_name

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(vm_in_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        return 'can not connect to libvirt! try delete again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            vm_uuid = conn_to_libvirt.get_uuid()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        return 'can not connect to libvirt'

    if vm_status == 1:
        # 开机修改配置函数
        disk_count = 0
        match_mount_point = 0
        ansible_kvm_host = [vm_in_host]

        print 'start to check whether mount point exist:'
        # 使用ansible校验待扩展mount点是否存在
        command_get_mount_point = "/bin/virt-cat -a /app/image/" + str(vm_uuid) + "/" + str(vm_name) + ".img" + " /etc/fstab | grep '^/dev'"
        ansible_get_mount_point_result = ansible_command_get(ansible_kvm_host, command_get_mount_point)
        if ansible_get_mount_point_result == 1 or ansible_get_mount_point_result == 2:
            conn_to_libvirt.close()
            return 'ansible error, please retry change disk or call system manager'
        elif ansible_get_mount_point_result[vm_in_host]['stdout'] == '':
            conn_to_libvirt.close()
            return 'ansible error, please retry change disk or call system manager'

        for vm_mount_point in ansible_get_mount_point_result[vm_in_host]['stdout'].split('\n'):
            if str(directory) == vm_mount_point.split()[1]:
                match_mount_point += 1
                vm_lv_name_in_fstab = vm_mount_point.split()[0].split('-')[1]
            else:
                pass
        if match_mount_point == 0:
            conn_to_libvirt.close()
            return 'mount point not found in os'
        else:
            print 'mount point exist!'

        print 'start to check whether the disk you want to expand is data disk, not system disk:'
        # 使用ansible校验待扩容卷是否为数据盘
        command_get_disk_lv_name = '/bin/virt-df -h -a /app/image/' + str(vm_uuid) + '/' + str(vm_name) + '.disk1'
        ansible_get_disk_lv_name_result = ansible_command_get(ansible_kvm_host, command_get_disk_lv_name)
        if ansible_get_disk_lv_name_result == 1 or ansible_get_disk_lv_name_result == 2:
            conn_to_libvirt.close()
            return 'ansible error, please retry change disk or call system manager'
        elif ansible_get_disk_lv_name_result[vm_in_host]['stdout'] == '':
            conn_to_libvirt.close()
            return 'ansible error, please retry change disk or call system manager'

        vm_lv_name = ansible_get_disk_lv_name_result[vm_in_host]['stdout']
        if vm_lv_name_in_fstab in vm_lv_name:
            print 'start to expand disk:'
        else:
            conn_to_libvirt.close()
            return "mount point '" + str(directory) + "' not permit to expand!"

        try:
            for disk in conn_to_libvirt.get_disk_device():
                if disk['dev'] == 'vdb':
                    disk_current_size = conn_to_libvirt.get_volume_by_path(disk['path']).info()[1] / 1073741824
                    disk_size = disk_current_size + int(add_size)
                    conn_to_libvirt.resize_disk(disk['image'], disk_size)
                    disk_count += 1
                    print 'expand disk to ' + str(disk_size) + 'G'
                else:
                    pass
        except libvirtError as err:
            conn_to_libvirt.close()
            return 'libvirt error, resize disk fail'

        if disk_count == 0:
            conn_to_libvirt.close()
            return 'can not find disk vdb'

        print 'start to expand logic volume:'

        instance = conn_to_libvirt.get_instance(vm_name)
        print 'test whether qemu agent is ok'
        command_for_qemu_agent_test = '/bin/uptime'
        # 使用qemu agent下发脚本扩容逻辑卷大小
        try:
            libvirt_qemu.qemuAgentCommand(instance, '{"execute":"exe-cmd","arguments":{"cmd":"%s"}}' % command_for_qemu_agent_test, 600, 0)
        except libvirtError as err:
            conn_to_libvirt.close()
            return "qemu agent connect fail, please login to vm " + str(vm_name) + " and run 'sh /root/resize_volume.sh'"
        print 'qemu agent connect successful!'
        command_for_qemu_agent = '/bin/bash /root/resize_volume.sh'
        libvirt_qemu.qemuAgentCommand(instance, '{"execute":"exe-cmd","arguments":{"cmd":"%s"}}' % command_for_qemu_agent, 600, 0)
        conn_to_libvirt.close()
        print 'finsh to expand logic volume'
        msg = 'all job done, successful to expand volume'
        logging.info(msg)
        return msg

        """
        try:
            for disk in conn_to_libvirt.get_delete_disk_device(vm_uuid):
                if 'img' not in disk['path']:
                    print 'image:' + disk['image'], '   ', 'dev:' + disk['dev'], '   ', 'current_size:' + str(int(conn_to_libvirt.get_volume_by_path(disk['path']).info()[1])/1073741824), 'G   '
        except libvirtError as err:
            conn_to_libvirt.close()
            return 'can not get status of volumes'
        """
        # disk_name = raw_input("input which dev you want to resize(like vdb): ")
        """
        disk_size = raw_input("disk size you want to resize(like 40, unit:G): ")

        # if disk_name == '' or disk_size == '':
        if disk_size == '':
            conn_to_libvirt.close()
            return 'empty input'
        elif not disk_size.isdigit():
            conn_to_libvirt.close()
            return 'error disk size input: ' + disk_size

        print 'start to resize volume:'

        try:
            for disk in conn_to_libvirt.get_disk_device():
                if 'img' not in disk['path']:
                    # if disk['dev'] == disk_name:
                    if disk['dev'] == 'vdb':
                        disk_count += 1
                        if int(conn_to_libvirt.get_volume_by_path(disk['path']).info()[1]) / 1073741824 >= int(disk_size):
                            conn_to_libvirt.close()
                            return 'disk size can not same as now or less than now!'
                        else:
                            try:
                                conn_to_libvirt.resize_disk(disk['image'], disk_size)
                                return 'disk size resize ' + 'to ' + disk_size + 'G'
                            except libvirtError as err:
                                conn_to_libvirt.close()
                                return 'libvirt error, resize disk fail'
            conn_to_libvirt.close()
            if disk_count == 0:
                # return 'can not find disk dev ' + disk_name
                return 'can not find disk dev vdb'
        except libvirtError as err:
            conn_to_libvirt.close()
            return 'can not get status of volumes'
        """
    else:
        conn_to_libvirt.close()
        return 'vm can only resize disk when starting'
