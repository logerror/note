package concurrent;

public class StopThread {
	
	/*
	 * count i = 590202543
		count i = 594689150
	 * */
	public static void main(String []args){
		Thread t1 = new Thread(new Runner(), "countthread");
		t1.start();
		SleepUtil.second(1);
		t1.interrupt();
		
		Runner r2 = new Runner();
		Thread t2 = new Thread(r2, "countthread");
		t2.start();
		SleepUtil.second(1);
		r2.cancel();
	}
	
	private static class Runner implements Runnable{
		
		private long i;
		//switch is true at the first
		private volatile boolean on =true;
		
		@Override
		public void run(){
			while(on && !Thread.currentThread().isInterrupted()){
				i++;
			}
			System.out.println("count i = "+i);
		}
		
		public void cancel(){
			on=false;
		}
	}
	
}
