# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
import time
from libvirt import libvirtError

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_vnc_address_get(vm_name):
    retry_conn_libvirt = 0
    retry_get_vnc_port = 0
    succeed_to_conn_libvirt = False
    succeed_to_get_vnc_port = False
    vm_in_host = ''
    vnc_port = ''

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
    db_session.commit()
    db_session.close()
    if vm_in_host == '':
        return 'can not found vm ' + vm_name

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        return 'can not connect to libvirt'

    if conn_to_libvirt.get_status() != 1:
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' is not running, start first !'
    elif conn_to_libvirt.get_status() == 1:
        while retry_get_vnc_port < 3 and not succeed_to_get_vnc_port:
            try:
                vnc_port = conn_to_libvirt.get_console_port()
                succeed_to_get_vnc_port = True
            except libvirtError as err:
                time.sleep(1)
                retry_get_vnc_port += 1
        if retry_get_vnc_port == 3:
            conn_to_libvirt.close()
            return 'can not get vnc port for vm ' + vm_name
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' vnc address is ' + vm_in_host + ':' + vnc_port




