# -*- coding:utf-8 -*-

# mysql数据库连接信息,这里改为自己的账号
SQLALCHEMY_DATABASE_URI = "mysql://root:sf123456@localhost:3306/vsvirmgr"

# list of console types
QEMU_CONSOLE_TYPES = ['vnc', 'spice']

# default console type
QEMU_CONSOLE_DEFAULT_TYPE = 'vnc'

# url for migrate
VS_MIGRATE_URL_SIT = 'http://10.202.41.24:8080/api/vm_migrate'

# migrate passwd
MIGRATE_PASSWORD = 'sfkj@useradd'

# username and passwd for ansible
AB_REMOTE_USER = 'sflog'
AB_REMOTE_SU_USER = 'sfroot'
AB_REMOTE_USER_PASSWD = 'Ken930dy'
AB_REMOTE_SU_USER_PASSWD = 'Kendy930'
