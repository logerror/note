# -*- coding:utf-8 -*-
# __author__ = '郭思远'


from kvm_command_platform.setting import VS_MIGRATE_URL_SIT, MIGRATE_PASSWORD, SQLALCHEMY_DATABASE_URI
import requests
import json
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo, HostInfo
import time
from libvirt import libvirtError
from kvm_command_platform import log_helper
import logging

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_migrate(vm_name, dst_host):
    log_handler = log_helper.init_log('vm_migrate')
    # 调用接口前验证入参合法性以及虚拟机状态
    retry_conn_libvirt = 0
    succeed_to_conn_libvirt = False
    vm_in_host = ''
    host_sn = ''
    vm_status = 0
    vm_snapshot_count = 0

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
    if vm_in_host == '':
        return 'can not found vm ' + vm_name
    elif vm_in_host == dst_host:
        return 'can not migrate to the same host ! ! !'

    for db_host_info in db_session.query(HostInfo).filter(HostInfo.host_ip == dst_host):
        host_sn = db_host_info.sn

    db_session.commit()
    db_session.close()
    if host_sn == '':
        return 'can not found host ip ' + dst_host

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(vm_in_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        return 'can not connect to libvirt! try migrate again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            vm_snapshot_count = conn_to_libvirt.instance.snapshotNum()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        return 'can not connect to libvirt'

    if vm_status != 5:
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' is running now, please stop vm and retry migrate!'

    if vm_snapshot_count != 0:
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' has snapshot, please delete snapshot and retry migrate!'

    data = {vm_name: dst_host}
    data_for_migrate = json.dumps(data)
    r = requests.post(VS_MIGRATE_URL_SIT, data=data_for_migrate, auth=('admin', MIGRATE_PASSWORD))

    conn_to_libvirt.close()
    if str(r.status_code) == '200':
        msg = 'connect migrate interface successful, check celery log in /root/vsvirmgr/celerylog1 !'
        logging.info(msg)
        return msg
    else:
        msg = 'can not connect to migrate interface, please check vs interface available !'
        logging.info(msg)
        return msg
