package concurrent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DeprecatedMethod {
	
	public static void main(String []args){
		Thread print  = new Thread(new Runner(),"PrintThread");
		DateFormat df = new SimpleDateFormat("HH:mm:ss"); 
		print.setDaemon(true);
		print.start();
		System.out.println( print.isAlive());
		print.suspend();
		System.out.println( print.isAlive());
		SleepUtil.second(3);
		System.out.println( "main suspend print thread at "
				+df.format(new Date()));
		print.resume();
		System.out.println( print.isAlive());
		SleepUtil.second(3);
		System.out.println( "main resume print thread at "
				+df.format(new Date()));
		print.stop();
		System.out.println( print.isAlive());
		SleepUtil.second(3);
		System.out.println( "main stop print thread at "
				+df.format(new Date()));
		SleepUtil.second(1);
		System.out.println( print.isAlive());
	}
 
	static class Runner implements Runnable{
		@Override
		public void run(){
			DateFormat format   = new SimpleDateFormat("HH:mm:ss");
			while(true){
				System.out.println(Thread.currentThread().getName()+" " +" run at "+
						format.format(new Date()));
				SleepUtil.second(1);
			}
		}
	}
}
