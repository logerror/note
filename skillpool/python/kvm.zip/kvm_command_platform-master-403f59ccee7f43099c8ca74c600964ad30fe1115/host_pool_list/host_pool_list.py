# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from kvm_command_platform.db_table_define import HostInfo
from prettytable import PrettyTable


db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def host_pool_list(pool_id):

    host_sn = ''
    db_record = []
    for db_host_info in db_session.query(HostInfo).filter(HostInfo.host_pool == pool_id):
        host_sn = db_host_info.sn
        db_record.append(db_host_info)
    if host_sn == '':
        print 'can not found pool id ' + pool_id
        return 0

    # 使用列表形式打印物理机信息
    attribute = PrettyTable(["host_ip", "sn", "env", "net_area", "host_pool"])
    attribute.align['host_ip'] = '1'
    attribute.padding_width = 1

    for db_per_record in db_record:
        attribute.add_row([db_per_record.host_ip, db_per_record.sn, db_per_record.env, db_per_record.net_area, db_per_record.host_pool])
    db_session.commit()
    db_session.close()
    print '\nPOOL ' + str(pool_id) + ' HAS ' + str(len(db_record)) + ' KVM HOST\n'
    print attribute
    return 0

