# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from sqlalchemy import Column, String, Integer
from sqlalchemy.ext.declarative import declarative_base

dbBase = declarative_base()


class HostInfo(dbBase):
    __tablename__ = 'host_info'
    host_ip = Column(String(32), primary_key=True, unique=True)
    env = Column(String(32))
    net_area = Column(String(32))
    host_pool = Column(String(32))
    sn = Column(String(32))


class VmInfo(dbBase):
    __tablename__ = 'vm_info'
    vm_ip = Column(String(32), primary_key=True, unique=True)
    vm_name = Column(String(32))
    env = Column(String(32))
    net_area = Column(String(32))
    host = Column(String(32))
    app_name = Column(String(32))
    cluster_id = Column(String(32))
    vm_cpu = Column(Integer)
    vm_mem = Column(Integer)
    vm_disk = Column(Integer)
    vm_status = Column(Integer)
    taskid = Column(String(32))



