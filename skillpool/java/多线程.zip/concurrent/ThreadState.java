package concurrent;

import java.util.concurrent.TimeUnit;

public class ThreadState {

	public static void main(String []args){
 		new Thread(new TimeWaiting(),"TimeWaitingThread").run();
 		new Thread(new Waiting(),"WaitingThread").run();
		new Thread(new Blocked(),"BlockedThread-1").run();
 		new Thread(new Blocked(),"BlockedThread-2").run();
		
	}
	static class TimeWaiting implements Runnable{
		@Override
		public void run() {
			while(true){
				SleepUtils.second(100);
			}
		}
	}

	static class Waiting implements Runnable{
		@Override
		public void run(){
			while(true){
				synchronized(Waiting.class){
					try{
						Waiting.class.wait();
						System.out.println("调用wait方法，会释放对象的锁，只有等待另外线程的通知或被中断才返回");
					}catch(InterruptedException e ){
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	static class Blocked implements Runnable{

		@Override
		public void run() {
			synchronized(Blocked.class){
				while(true){
					SleepUtils.second(100);
				}
			}
		}
		
	}
	
	static class SleepUtils{
		public static final void second(long seconds){
			try{
				TimeUnit.SECONDS.sleep(seconds);
				Thread.sleep(1);
			}catch(InterruptedException e){
				System.out.println(e.getMessage());
			}
		}
	}
	
}
