# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
import time
from libvirt import libvirtError
from kvm_command_platform import log_helper
import logging


db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_stop(vm_name):
    log_handler = log_helper.init_log('vm_stop')
    retry_conn_libvirt = 0
    retry_vm_stop = 0
    succeed_to_conn_libvirt = False
    succeed_vm_stop = False
    vm_in_host = ''
    vm_status = 0

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
    db_session.commit()
    db_session.close()
    if vm_in_host == '':
        return 'can not found vm ' + vm_name

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(vm_in_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        return 'can not connect to libvirt! try stop again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        return 'can not connect to libvirt'

    if vm_status != 1:
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' is not running, do not try to stop !'
    elif vm_status == 1:
        while retry_vm_stop < 3 and not succeed_vm_stop:
            try:
                conn_to_libvirt.shutdown()
                print 'stopping... ...'
                time.sleep(8)
                succeed_vm_stop = True
            except libvirtError as err:
                time.sleep(1)
                retry_vm_stop += 1
        if retry_vm_stop == 3:
            conn_to_libvirt.close()
            return 'can not shutdown vm ' + vm_name
        conn_to_libvirt.close()
        msg = 'vm ' + vm_name + ' stop successful'
        logging.info(msg)
        return msg
    else:
        conn_to_libvirt.close()
        return 'vm ' + vm_name + ' is not running now'
