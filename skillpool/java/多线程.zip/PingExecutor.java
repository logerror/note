package com.sf.vishnu.proxy.executer.plugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sf.vishnu.proxy.common.Input;
import com.sf.vishnu.proxy.common.Output;
import com.sf.vishnu.proxy.common.Param;
import com.sf.vishnu.proxy.dto.ResponseVo;
import com.sf.vishnu.proxy.executer.factory.ExecuterBase;

import net.sf.json.JSONObject;

@Component
public class PingExecutor extends ExecuterBase {

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "ping";
	}

	/*
	 * 执行器需要传ips给过来 
	 */
	@Input({ @Param(name = "参数1", type = "JSONObject", desc = "Json对象") })
	@Output({ @Param(name = "参数2", type = "Object", desc = "日志信息") })
	@Override
	protected void myExecute(JSONObject jsonObj, ResponseVo responseVo) {
		Logger log=LoggerFactory.getLogger(PingExecutor.class);
		String ips = jsonObj.get("ips").toString().trim();
		String command = "/bin/ping -c 2 ";
		Process p=null;
		Runtime proc = null;
		try {
			log.info("ping executor enter in ");
			proc = Runtime.getRuntime();
			p=proc.exec(command+ips);
			 // 取得命令结果的输出流   
           InputStream fis = p.getInputStream();   

           // 用一个读输出流类去读    
           InputStreamReader isr = new InputStreamReader(fis,"GBK");   

           // 用缓冲器读行   
           BufferedReader br = new BufferedReader(isr);   

           String line = null;   
            StringBuffer sb = new StringBuffer();
           // 直到读完为止   
           while ((line = br.readLine()) != null) {   
                sb.append(line+"\r\n");
           }   
			p.waitFor();
			if (p.exitValue() != 0) { //ping不通，表示ip可用
				log.info("ping unreached first time, ip is available");
				p = proc.exec(command+ips);
				p.waitFor();
				if(p.exitValue()!=0) {
					log.info("ping unreached sencond time, ip is available");
					responseVo.setResponse(sb.toString());
					responseVo.setStatus("ok");
				}
			}else{ // ip不可用,ping通了
				log.info("ping tong le, ip is unavailable");
				responseVo.setStatus("fail");
				responseVo.setError(sb.toString());
			}
		} catch (IOException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		} catch (InterruptedException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
	}

}
