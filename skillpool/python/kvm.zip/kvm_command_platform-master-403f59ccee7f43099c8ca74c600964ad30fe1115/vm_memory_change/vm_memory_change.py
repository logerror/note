# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
import time
from libvirt import libvirtError
from kvm_command_platform import log_helper
import logging

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_memory_change(vm_name, vmemory):
    log_handler = log_helper.init_log('vm_memory_change')
    vm_in_host = ''
    retry_conn_libvirt = 0
    retry_vm_memory_change = 0
    succeed_to_conn_libvirt = False
    succeed_vm_memory_changes = False
    vm_status = 0

    if not vmemory.isdigit():
        return 'error input ' + vmemory

    if int(vmemory) < 2:
        return 'dangerous: vm memory not allow less than 2G !'
    elif int(vmemory) > 100:
        return 'dangerous: not permit vm to have more than 100G!'

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
    db_session.commit()
    db_session.close()
    if vm_in_host == '':
        return 'can not found vm ' + vm_name

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(vm_in_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        return 'can not connect to libvirt! try delete again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        return 'can not connect to libvirt'

    print 'start to change memory:'
    if vm_status == 5:
        # 关机修改配置函数
        vm_memory_before_change = int(conn_to_libvirt.get_memory())/1024
        if int(vmemory) == vm_memory_before_change:
            conn_to_libvirt.close()
            return 'warn: memory of vm ' + vm_name + ' is now ' + vmemory + 'G!'
        try:
            conn_to_libvirt.change_vm_memory(int(vmemory)*1024, int(vmemory)*1024)
            vm_memory = conn_to_libvirt.get_memory()
        except libvirtError as err:
            conn_to_libvirt.close()
            return 'libvirt error, can not change memory'
        conn_to_libvirt.close()
        # 更改成功后修改数据库
        vm_info = db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name).first()
        vm_info.vm_mem = int(vm_memory)
        db_session.commit()
        db_session.close()
        msg = 'vm ' + vm_name + ' memory change from ' + str(vm_memory_before_change) + 'G to ' + str(vm_memory/1024) + 'G'
        logging.info(msg)
        return msg
    elif vm_status == 1:
        conn_to_libvirt.close()
        return 'please stop vm and retry memory change'
    else:
        conn_to_libvirt.close()
        return 'unrecognized vm state'

    """
        elif vm_status == 1:
            # 开机修改配置函数
            vm_memory_before_change = int(conn_to_libvirt.get_cur_memory())/1024
            if int(vmemory) == int(vm_memory_before_change):
                conn_to_libvirt.close()
                return 'warn: your input memory count the same as now, nothing to do!'
            else:
                try:
                    conn_to_libvirt.change_vm_memory_active(int(vmemory))
                except libvirtError as err:
                    conn_to_libvirt.close()
                    db_session.commit()
                    db_session.close()
                    return 'change memory fail!'
                vm_memory = conn_to_libvirt.get_cur_memory()
                conn_to_libvirt.close()
                # 更改成功后修改数据库
                vm_info = db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name).first()
                vm_info.vm_mem = int(vmemory)*1024
                db_session.commit()
                db_session.close()
            return 'done'
        """
