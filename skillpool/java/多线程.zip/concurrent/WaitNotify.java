package concurrent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class WaitNotify {

	static boolean flag = true;
	static Object lock = new Object();
	
	/*
	 * Thread[waitThread,5,main]flag is true,wait at15:55:51
	Thread[notifyThread,5,main] hold lock, notify at15:55:52
	Thread[notifyThread,5,main] hold lock again, notify at15:55:57
	Thread[waitThread,5,main]flag is false,running at15:56:02
	 * */
	public static void main(String[] args) throws Exception{

		Thread wait = new Thread(new Wait(), "waitThread");
		wait.start();
		TimeUnit.SECONDS.sleep(1);
		Thread notify = new Thread(new Notify(), "notifyThread");
		notify.start();
	}

	static class Wait implements Runnable{
		@Override
		public void run(){
			synchronized(lock){
				while(flag){
					try{
						System.out.println(Thread.currentThread()+"flag is true,"
								+ "wait at"+new SimpleDateFormat("HH:mm:ss").format(new Date()));
						lock.wait();
					}catch(InterruptedException e){
						e.printStackTrace();
					}
				} 
				
				//while flag is false;
				System.out.println(Thread.currentThread()+"flag is false,"
								+ "running at"+new SimpleDateFormat("HH:mm:ss").format(new Date()));
			}
		}

	}
	
	static class Notify implements Runnable{

		@Override
		public void run() {
			synchronized(lock){
				System.out.println(Thread.currentThread()+" hold lock, notify at"
						+new SimpleDateFormat("HH:mm:ss").format(new Date()));
				lock.notifyAll();
				flag=false;
				SleepUtil.second(2);
			}
			
			// add lock again
			synchronized(lock){
				System.out.println(Thread.currentThread()+" hold lock again, notify at"
						+new SimpleDateFormat("HH:mm:ss").format(new Date()));
				SleepUtil.second(2);
			}
		}
	}
	
}
