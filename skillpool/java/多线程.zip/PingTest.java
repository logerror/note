package com.sf.vishnu.proxy.executer.plugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sf.vishnu.proxy.common.CountTask;
import com.sf.vishnu.proxy.common.Input;
import com.sf.vishnu.proxy.common.Output;
import com.sf.vishnu.proxy.common.Param;
import com.sf.vishnu.proxy.dto.ResponseVo;
import com.sf.vishnu.proxy.executer.factory.ExecuterBase;
import com.sf.vishnu.proxy.executer.factory.ExecutorPoolBase;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class PingTest extends ExecutorPoolBase{
	private static final long serialVersionUID = -5388047013667700750L;
	private Logger log=LoggerFactory.getLogger(PingTest.class);
	private String ip;
	private int size;
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
	public PingTest() {}
	public PingTest(String ip,int size) {
		this.ip=ip;
		this.size=size;
	}
	
	@Override
	public String getType() {
		return "ping_tp";
	}

	@Override
	protected ResponseVo compute() {
		ResponseVo res = new ResponseVo();
		JSONObject json = new JSONObject();
		String iparray[] = null ;
		List<PingTest> pingtask = new ArrayList<PingTest>();
		int oksize = 0;
		JSONArray oka = new JSONArray();
		JSONArray faila = new JSONArray();
		
		boolean totalstatus = false;
		if(size>1)
		{
			iparray= ip.split(",");	
			for(int i=0;i<size;i++) {
				PingTest task=new PingTest(iparray[i],0);
				pingtask.add(task);
				task.fork();
			}
			for(int i=0;i<size;i++) {
				ResponseVo rvo = pingtask.get(i).join();
				if(rvo.getStatus().equalsIgnoreCase("fail")) {
					totalstatus = true;
					faila.add(iparray[i]);
				}else {
					oksize++;
					oka.add(iparray[i]);
				}
			}
			json.put("ok", oka);
			json.put("fail", faila);
			json.put("size", oksize);
			res.setResponse(json);
			res.setStatus(totalstatus?"fail":"ok");
		}else {
			res=executeping(ip);
			if(res.getStatus().equalsIgnoreCase("ok")) {
				oka.add(ip);
				json.put("ok", oka);
				json.put("size", 1);
			}else {
				faila.add(ip);
				json.put("fail", faila);
			}
			res.setResponse(json);
		}
		return res;
	}

	protected ResponseVo executeping(String newip) {
		ResponseVo responseVo = new ResponseVo();
	//	String command = "/bin/ping -c 2 ";
		String command = "ping "+newip;
		Process p=null;
		Runtime proc = null;
		try {
			log.info("ping executor enter in ");
			proc = Runtime.getRuntime();
			p=proc.exec(command);
			/* // 取得命令结果的输出流   
           InputStream fis = p.getInputStream();   
           // 用一个读输出流类去读    
           InputStreamReader isr = new InputStreamReader(fis,"GBK");   
           // 用缓冲器读行   
           BufferedReader br = new BufferedReader(isr);   
           String line = null;   
            StringBuffer sb = new StringBuffer();
           // 直到读完为止   
           while ((line = br.readLine()) != null) {   
                sb.append(line+"\r\n");
           }   */
			p.waitFor();
			if (p.exitValue() != 0) { //ping不通，表示ip可用
				log.info("ping unreached first time, ip is available");
				p = proc.exec(command);
				p.waitFor();
				if(p.exitValue()!=0) {
					log.info("ping unreached sencond time, ip is available");
					responseVo.setResponse("ping unreached sencond time, ip is available\r\n");
					responseVo.setStatus("ok");
				}
			}else{ // ip不可用,ping通了
				log.info("ping tong le, ip is unavailable");
				responseVo.setStatus("fail");
				responseVo.setResponse("ping tong le, ip is unavailable\r\n");
			}
		} catch (IOException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		} catch (InterruptedException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
		return responseVo;
	}


	public static void main(String []args) {
		//using Runtime.availableProcessors()
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		String ips = "10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,"
				+ "10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61"+
				"10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,"
				+ "10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61";
		int size = 1;
		if(ips.contains(",")) {
			size=ips.split(",").length;
		}else {
			size=1;
		}
		PingTest ping = new PingTest(ips,size);
		Future<ResponseVo> result = forkJoinPool.submit(ping);
		try {
			ResponseVo res = result.get();
			System.out.println(res);
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void myExecute(JSONObject jsonObj, ResponseVo responseVo) throws Throwable {
		// TODO Auto-generated method stub
		
	}
}
