# -*- coding:utf-8 -*-
# __author__ = '郭思远'
import logging
import os
import logging.handlers


def init_log(service_name):
    log_basic_path = os.path.dirname(os.path.abspath(__file__))[0:-20]
    logName = log_basic_path + 'log/' + str(service_name) + '.log'
    addTimedRotatingFileHandler(logName, logLevel='DEBUG')


def addTimedRotatingFileHandler(filename, **kwargs):
    '''
        给logger添加一个时间切换文件的handler。
        默认时间是0点开始备份。
        如果不指定logger，则使用logging.getLogger()，也就是RootLogger。
    '''
    dname = os.path.dirname(filename)
    if dname and not os.path.isdir(dname):
        os.makedirs(dname, 0755)
    conf = {
        'when': 'midnight',
        'backupCount': kwargs.get('backupCount',30),
        'format': '[%(asctime)s][%(filename)s-L%(lineno)d][%(levelname)s]: %(message)s',
        'logger': logging.getLogger(),
    }
    conf.update(kwargs)
    if conf.has_key('logLevel'):
        if isinstance(conf['logLevel'], str):
            conf['logLevel'] = getattr(logging, conf['logLevel'])
        conf['logger'].setLevel(conf['logLevel'])
    handler = logging.handlers.TimedRotatingFileHandler(
        filename = filename,
        when = conf['when'],
        backupCount = conf['backupCount'],
    )
    handler.setFormatter(
        logging.Formatter(conf['format'])
    )
    conf['logger'].addHandler(handler)
    return handler