package concurrent;

public class Synchronized {
	public static void main(String []args)
	{
		synchronized(Synchronized.class){
			
		}
	}
	public static synchronized void m(){
		
	}
}
