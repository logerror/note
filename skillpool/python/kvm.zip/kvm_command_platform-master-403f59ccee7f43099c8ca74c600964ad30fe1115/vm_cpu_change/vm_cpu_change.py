# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
import time
from libvirt import libvirtError
from kvm_command_platform import log_helper
import logging

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_cpu_change(vm_name, vcpu):
    log_handler = log_helper.init_log('vm_cpu_change')
    vm_in_host = ''
    retry_conn_libvirt = 0
    succeed_to_conn_libvirt = False
    vm_status = 0

    if not vcpu.isdigit():
        return 'error input ' + vcpu

    if int(vcpu) < 2:
        return 'dangerous: cpu count not allow less than 2 !'
    elif int(vcpu) > 16:
        return 'dangerous: not permit vm to have more than 16 core!'

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host

    if vm_in_host == '':
        db_session.commit()
        db_session.close()
        return 'can not found vm ' + vm_name

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(vm_in_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        db_session.commit()
        db_session.close()
        return 'can not connect to libvirt! try delete again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        db_session.commit()
        db_session.close()
        return 'can not connect to libvirt'

    if vm_status == 5:
        print 'start to change cpu number:'
        # 关机修改配置函数
        vm_cpu_before_change = conn_to_libvirt.get_cur_vcpu()
        if int(vm_cpu_before_change) == int(vcpu):
            db_session.commit()
            db_session.close()
            conn_to_libvirt.close()
            return 'warn: your input cpu count the same as now, nothing to do!'
        try:
            conn_to_libvirt.change_vm_cpu(str(vcpu), str(20))
            vm_cpu = conn_to_libvirt.get_cur_vcpu()
        except libvirtError as err:
            conn_to_libvirt.close()
            db_session.commit()
            db_session.close()
            return 'libvirt error, can not change cpu'
        conn_to_libvirt.close()
        # 更改成功后修改数据库
        vm_info = db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name).first()
        vm_info.vm_cpu = int(vm_cpu)
        db_session.commit()
        db_session.close()
        msg = 'vm ' + vm_name + ' cpu change from ' + str(vm_cpu_before_change) + 'core to ' + str(vm_cpu) + 'core'
        logging.info(msg)
        return msg
    elif vm_status == 1:
        print 'start to change cpu number:'
        # 开机修改配置函数
        vm_cpu_before_change = conn_to_libvirt.get_cur_vcpu()
        if int(vm_cpu_before_change) == int(vcpu):
            db_session.commit()
            db_session.close()
            conn_to_libvirt.close()
            return 'warn: your input cpu count the same as now, nothing to do!'
        elif int(vcpu) < int(vm_cpu_before_change):
            db_session.commit()
            db_session.close()
            conn_to_libvirt.close()
            return 'you want to subtraction the cpu, please shutdown vm and retry to do!'
        else:
            try:
                conn_to_libvirt.change_vm_cpu_active(int(vcpu))
            except libvirtError as err:
                conn_to_libvirt.close()
                db_session.commit()
                db_session.close()
                return 'change cpu fail!'
            vm_cpu = conn_to_libvirt.get_cur_vcpu()
            conn_to_libvirt.close()
            # 更改成功后修改数据库
            vm_info = db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name).first()
            vm_info.vm_cpu = int(vm_cpu)
            db_session.commit()
            db_session.close()
        msg = 'vm ' + vm_name + ' cpu change from ' + str(vm_cpu_before_change) + 'core to ' + str(vm_cpu) + 'core'
        logging.info(msg)
        return msg
    else:
        db_session.commit()
        db_session.close()
        conn_to_libvirt.close()
        return 'unrecognized vm state'
