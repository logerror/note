package concurrent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ThreadPoolTest {

	public static void main(String []args){
		int count = 6;
		CountDownLatch cdl = new CountDownLatch(count);
		 for(int i =0;i<count;i++){
			ThreadTest t = new ThreadTest();
			/*CommonThreadPool.execute(new Thread(){
				@Override
				public void run(){
					try {
						TimeUnit.SECONDS.sleep(1l);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("in thread ");
				}
			});*/
			CommonThreadPool.execute(t);
			cdl.countDown();
		} 
		try{
			cdl.await();
		}catch(InterruptedException e ){
			System.out.println("executor is exception");
		}
		CommonThreadPool.shutdown();     
		System.out.println("executor is finish");
	}
}

class ThreadTest implements Runnable{
	private static Logger log=LoggerFactory.getLogger(ThreadTest.class);
	@Override
	public void run() {
		log.error("this is a test");
		try {
			Thread.sleep(3L);
			//	TimeUnit.SECONDS.sleep(3L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
	}
}
