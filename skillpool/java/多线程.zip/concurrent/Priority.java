package concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Priority {

	private static volatile boolean nonStart = true;
	private static volatile boolean nonEnd =true;
	
	public static void main(String[] args) throws InterruptedException {
		
		List<Job> joblist = new ArrayList<Job>();
		for(int i=0;i<10;i++){
			int priority = i<5?Thread.MIN_PRIORITY:Thread.MAX_PRIORITY;
			Job job = new Job(priority);
			joblist.add(job);
			Thread thread = new Thread(job, "Thread:"+i);
			thread.setPriority(priority);
			thread.start();
		}
		
		nonStart =false;
		TimeUnit.SECONDS.sleep(10);
		
		nonEnd = false;
		for(Job job : joblist){
			System.out.println("job priority:"+job.priority + " count:" +job.jobCount);
		}
		
	}

	static class Job implements Runnable{
		private int priority;
		private long jobCount=0;
		
		public Job(int priority){
			this.priority=priority;
		}

		@Override
		public void run() {
			while(nonStart){
				Thread.yield();
			}
			while(nonEnd){
				Thread.yield();
				jobCount++;
			}
			
		}
		
	}
}
