package concurrent;

import java.util.concurrent.TimeUnit;

public class DaemonThread {

	public static void main(String[] args) {

		Thread daemonThread = new Thread(new Daemon(),"DaemonThread");
		daemonThread.setDaemon(true);
		daemonThread.start();
		System.out.println("over main thread");
	}

	static class Daemon implements Runnable{
		@Override
		public void run(){
			try{
				TimeUnit.SECONDS.sleep(10);
			}catch(Exception e){
				
			}finally{
				System.out.println("never reached");
			}
			
		}
	}
	
	
	
}
