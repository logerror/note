package com.sf.vishnu.proxy.executer.plugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sf.vishnu.proxy.dto.ResponseVo;
import com.sf.vishnu.proxy.executer.factory.ExecutorPoolBase;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Component
public class PingExecutor2 extends ExecutorPoolBase {
	private static final long serialVersionUID = -5388047013667700750L;
	private Logger log=LoggerFactory.getLogger(PingExecutor2.class);
	private String ip;
	private int size;
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
	public PingExecutor2() {}
	public PingExecutor2(String ip,int size) {
		this.ip=ip;
		this.size=size;
	}
	@Override
	public String getType() {
		return "ping2_old";
	}


	@Override
	protected ResponseVo compute() {
		ResponseVo res = new ResponseVo();
		JSONObject json = new JSONObject();
		String iparray[] = null ;
		List<PingExecutor2> pingtask = new ArrayList<PingExecutor2>();
		int oksize = 0;
		JSONArray oka = new JSONArray();
		JSONArray faila = new JSONArray();
		boolean totalstatus = false;
		if(size>1)
		{
			iparray= ip.split(",");	
			for(int i=0;i<size;i++) {
				PingExecutor2 task=new PingExecutor2(iparray[i],0);
				pingtask.add(task);
				task.fork();
			}
			for(int i=0;i<size;i++) {
				ResponseVo rvo = pingtask.get(i).join();
				if(rvo.getStatus().equalsIgnoreCase("fail")) {
					totalstatus = true;
					faila.add(iparray[i]);
				}else {
					oksize++;
					oka.add(iparray[i]);
				}
			}
		}else {
			res=executeping(ip);
			if(res.getStatus().equalsIgnoreCase("ok")) {
				oka.add(ip);
				oksize++;
			}else {
				faila.add(ip);
				totalstatus = true;
			}
		}
		json.put("ok", oka);
		json.put("fail", faila);
		json.put("size", oksize);
		res.setResponse(json);
		res.setStatus(totalstatus?"fail":"ok");
		return res;
	}
	protected ResponseVo executeping(String newip) {
		ResponseVo responseVo = new ResponseVo();
		String command = "/bin/ping -c 2 "+newip;
		Process p=null;
		Runtime proc = null;
		try {
			log.info("ping executor enter in ");
			proc = Runtime.getRuntime();
			p=proc.exec(command);
			/* // 取得命令结果的输出流   
           InputStream fis = p.getInputStream();   
           // 用一个读输出流类去读    
           InputStreamReader isr = new InputStreamReader(fis,"GBK");   
           // 用缓冲器读行   
           BufferedReader br = new BufferedReader(isr);   
           String line = null;   
            StringBuffer sb = new StringBuffer();
           // 直到读完为止   
           while ((line = br.readLine()) != null) {   
                sb.append(line+"\r\n");
           }   */
			p.waitFor();
			if (p.exitValue() != 0) { //ping不通，表示ip可用
				log.info("ping unreached first time, ip is available");
				p = proc.exec(command);
				p.waitFor();
				if(p.exitValue()!=0) {
					log.info("ping unreached sencond time, ip is available");
					responseVo.setResponse("ping unreached sencond time, ip is available\r\n");
					responseVo.setStatus("ok");
				}
			}else{ // ip不可用,ping通了
				log.info("ping tong le, ip is unavailable");
				responseVo.setStatus("fail");
				responseVo.setResponse("ping tong le, ip is unavailable\r\n");
			}
		} catch (IOException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		} catch (InterruptedException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
		return responseVo;
	}

	@Override
	protected void myExecute(JSONObject jsonObj, ResponseVo responseVo) throws Throwable {
			//using Runtime.availableProcessors()
		ForkJoinPool forkJoinPool = new ForkJoinPool(12);
		String ips = jsonObj.getString("ips");
		int size = 0;
		if(ips.contains(",")) {
			size=ips.split(",").length;
		} 
		PingExecutor2 ping = new PingExecutor2(ips,size);
		Future<ResponseVo> result = forkJoinPool.submit(ping);
		try {
			ResponseVo res = result.get();
			responseVo.setResponse(res.getResponse());
			responseVo.setStatus(res.getStatus());
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
	}
}
