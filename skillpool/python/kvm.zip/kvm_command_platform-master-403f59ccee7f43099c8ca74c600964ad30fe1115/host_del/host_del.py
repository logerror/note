# -*- coding:utf-8 -*-
#author:anke
#the module is used to standardlize the kvm host
#usage


from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from kvm_command_platform.db_table_define import HostInfo
from kvm_command_platform.db_table_define import VmInfo
from vrtManager.instance import wvmInstances
from libvirt import libvirtError

#初始化db连接串信息
db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)
db_session = session()

def host_del(host_ip):

    ip_in_hostinfo = ''
    ip_in_vminfo=[]
    for db_host_info in db_session.query(HostInfo).filter(HostInfo.host_ip == host_ip):
        ip_in_hostinfo = db_host_info.host_ip
    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.host == host_ip):
        ip_in_vminfo.append(db_vm_info.vm_name)
    if ip_in_hostinfo != '':
        print "host "+host_ip+" found in db"
        #判断DB表中是否有vm存在该host上
        if len(ip_in_vminfo):
            print "host delete fail,according to db info,the vms below is still on the host "+host_ip+",please delete vms first!"
            print ip_in_vminfo
            db_session.commit()
            db_session.close()
            return "fail"


        else:
             db_session.delete(db_host_info)
             db_session.commit()
             db_session.close()
             return "host " + host_ip + " is deleted from db"
    else:
        db_session.commit()
        db_session.close()
        return "can not find host "+host_ip+" in db"



