# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import VmInfo
import time
from libvirt import libvirtError


db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_info(vm_name):

    vm_in_host = ''
    retry_conn_libvirt = 0
    succeed_to_conn_libvirt = False
    vm_status = 0

    vm_state_name_map = {0: 'running',
                         1: 'running',
                         2: 'running',
                         3: 'paused',
                         4: 'shutdown',
                         5: 'shutdown',
                         6: 'crashed'}

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        vm_in_host = db_vm_info.host
        # 获取虚拟机信息用于展示
        vm_ip = db_vm_info.vm_ip
        env = db_vm_info.env
        net_area = db_vm_info.net_area
        app_name = db_vm_info.app_name
        cluster_id = db_vm_info.cluster_id
        vm_cpu = db_vm_info.vm_cpu
        vm_mem = db_vm_info.vm_mem
        vm_disk = db_vm_info.vm_disk
        # vm_status = db_vm_info.vm_status

    db_session.commit()
    db_session.close()
    if vm_in_host == '':
        print 'can not found vm ' + vm_name
        return 1

    while retry_conn_libvirt < 3 and not succeed_to_conn_libvirt:
        try:
            conn_to_libvirt = wvmInstance(vm_in_host,
                                          'webvirmgr',
                                          'sf123456',
                                          1,
                                          vm_name)
            vm_status = conn_to_libvirt.get_status()
            vm_uuid = conn_to_libvirt.get_uuid()
            succeed_to_conn_libvirt = True
        except libvirtError as err:
            time.sleep(1)
            retry_conn_libvirt += 1

    if retry_conn_libvirt == 3:
        vm_status = 'unknown'
        vm_uuid = 'unknown'
        print 'name:           ' + str(vm_name)
        print 'ip:             ' + str(vm_ip)
        print 'uuid:           ' + str(vm_uuid)
        print 'host:           ' + str(vm_in_host)
        print 'cpu(s):         ' + str(vm_cpu)
        print 'current memory: ' + str(vm_mem)
        print 'disk:           ' + str(vm_disk)
        print 'vm status:      ' + str(vm_status)
        print 'env:            ' + str(env)
        print 'net area:       ' + str(net_area)
        print 'app name:       ' + str(app_name)
        print 'cluster id:     ' + str(cluster_id)
        return 0

    conn_to_libvirt.close()
    vm_status = vm_state_name_map[vm_status]

    print 'name:           ' + str(vm_name)
    print 'ip:             ' + str(vm_ip)
    print 'uuid:           ' + str(vm_uuid)
    print 'host:           ' + str(vm_in_host)
    print 'cpu(s):         ' + str(vm_cpu)
    print 'current memory: ' + str(vm_mem)
    print 'disk:           ' + str(vm_disk)
    print 'vm status:      ' + str(vm_status)
    print 'env:            ' + str(env)
    print 'net area:       ' + str(net_area)
    print 'app name:       ' + str(app_name)
    print 'cluster id:     ' + str(cluster_id)
    return 0


