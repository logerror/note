package com.sf.vishnu.proxy.executer.plugin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sf.vishnu.proxy.dto.ResponseVo;
import com.sf.vishnu.proxy.executer.factory.ExecuterBase;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

class PingNewTask implements Callable<ResponseVo>{
	private Logger log=LoggerFactory.getLogger(PingNewTask.class);
	private String ip ;
	
	public PingNewTask() {
	}
	public PingNewTask(String ip) {
		super();
		this.ip = ip;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	protected ResponseVo executeping(String newip) {
		ResponseVo responseVo = new ResponseVo();
		String command = "/bin/ping -c 2 ";
	//	String command = "ping "+newip;
		Process p=null;
		Runtime proc = null;
		try {
			log.info("ping executor enter in ");
			proc = Runtime.getRuntime();
			p=proc.exec(command);
			p.waitFor();
			if (p.exitValue() != 0) { //ping不通，表示ip可用
				log.info("ping unreached first time, ip is available");
				p = proc.exec(command);
				p.waitFor();
				if(p.exitValue()!=0) {
					log.info("ping unreached sencond time, ip is available");
					responseVo.setResponse("ping unreached sencond time, ip is available\r\n");
					responseVo.setStatus("ok");
				}
			}else{ // ip不可用,ping通了
				log.info("ping tong le, ip is unavailable");
				responseVo.setStatus("fail");
				responseVo.setResponse("ping tong le, ip is unavailable\r\n");
			}
		} catch (IOException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		} catch (InterruptedException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
		return responseVo;
	}
	
	@Override
	public ResponseVo call() throws Exception {
		return executeping(ip);
	}	
}
@Component
public class PingExecutor3 extends ExecuterBase{
	private Logger logger=LoggerFactory.getLogger(PingExecutor3.class);
	
	public PingExecutor3(int i) {
		super(i);
		// TODO Auto-generated constructor stub
	}

	public PingExecutor3() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void myExecute(JSONObject jsonObj, ResponseVo responseVo) throws Throwable{
		try {
			String ips = jsonObj.optString("ips");
			if(ips=="") {
				logger.error("传递的ip参数为空");
				responseVo.setStatus("fail");
				responseVo.setError("传递的ip参数为空");
				return;
			} 
			
			int count =0;
			String[] ipa = new String[100];
			if(ips.contains(",")) {
				ipa =ips.split(",");
				count=ipa.length;
			}else {
				ipa[0]=ips;
				count=1;
			}
			
			if(count>=100) {
				logger.error("单次传入的ip个数不能超过100个");
				responseVo.setStatus("fail");
				responseVo.setError("单次传入的ip个数不能超过100个");
				return;
			}
			
			boolean totalstatus = false;
			JSONArray faila = new JSONArray();
			JSONArray oka = new JSONArray();
			int oksize=0;
			JSONObject json = new JSONObject();
			//线程默认处理10个ping任务，最多不超过64个，如果超过10个，会分批处理最后合并结果
			ThreadPoolExecutor tpe = new ThreadPoolExecutor(10, 64, 0, TimeUnit.SECONDS, 
					new LinkedBlockingQueue<Runnable>(), new ThreadPoolExecutor.CallerRunsPolicy());
			List<Future<ResponseVo>> results = new LinkedList<Future<ResponseVo>>();
			
			for(int i=0;i<count;i++) {
				PingNewTask PingNewTask = new PingNewTask(ipa[i]);
				Future<ResponseVo> result= tpe.submit(PingNewTask);
				results.add(result);
			}
			
			for(int i=0;i<count;i++) {
				ResponseVo rvo =results.get(i).get();
				if(rvo.getStatus().equalsIgnoreCase("fail")) {
					totalstatus = true;
					faila.add(ipa[i]);
				}else {
					oksize++;
					oka.add(ipa[i]);
				}
			}
			
			json.put("ok", oka);
			json.put("fail", faila);
			json.put("size", oksize);
			responseVo.setResponse(json);
			responseVo.setStatus(totalstatus?"fail":"ok");
			
			tpe.shutdown();
			boolean terminationStatus = tpe.awaitTermination(1, TimeUnit.DAYS);
			System.out.println(terminationStatus);
			logger.info(responseVo.toString());
		}catch(Exception e) {
			logger.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
	} 

	public static void main(String[] args) throws Throwable {
		PingExecutor3 ping  = new PingExecutor3();
		PingExecutor3 ping2  = new PingExecutor3(12);
		JSONObject json = new JSONObject();
		json.put("ips", "8.8.8.8");
		ResponseVo res = new ResponseVo();
		ping.myExecute(json, res);
		
	}

	@Override
	public String getType() {
		return "ping2";
	}

	
}
