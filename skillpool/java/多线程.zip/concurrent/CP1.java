package concurrent;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CP1 {
    public static void main(String[] args) {
        Lock lock = new ReentrantLock();
        
        Consumer1 Consumer1 = new Consumer1(lock);
        Producer1 Producer1 = new Producer1(lock);
        
         new Thread(Consumer1).start();
         new Thread( Producer1).start();
        
  }
}
class Consumer1 implements Runnable {
	 
    private Lock lock;
    public Consumer1(Lock lock) {
           this. lock = lock;
    }
    @Override
    public void run() {
           // TODO Auto-generated method stub
           int count = 10;
           while( count > 0 ) {
                try {
                     lock.lock();
                    count --;
                    System. out.print( "B");
               } finally {
                     lock.unlock(); //主动释放锁
                     try {
                          Thread. sleep(91L);
                    } catch (InterruptedException e) {
                          e.printStackTrace();
                    }
               }
          }

    }

}

class Producer1 implements Runnable{

    private Lock lock;
    public Producer1(Lock lock) {
           this. lock = lock;
    }
    @Override
    public void run() {
           int count = 10;
           while (count > 0) {
                try {
                     lock.lock();
                    count --;
                    System. out.print( "A");
               } finally {
                     lock.unlock();
                     try {
                          Thread. sleep(90L);
                    } catch (InterruptedException e) {
                          e.printStackTrace();
                    }
               }
          }
    }
}
 

