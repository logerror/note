# -*- coding:utf-8 -*-
#__author__:anke
#the module is used to get host performance file from hosts

import paramiko
import logging
from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from kvm_command_platform.db_table_define import HostInfo


#构造db连接串信息
db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)
db_session = session()

#定义日志级别

logger_command_return = logging.getLogger('/home/sflog/log_get_host_perf')
logger_command_return.setLevel(logging.DEBUG)
fh_command_return = logging.FileHandler('log_ansible_command_return.log')
fh_command_return.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
fh_command_return.setFormatter(formatter)

#依次对db表中host取性能数据文件
def get_host_perfor():
    user = "sflog"
    passwd = "Ken930dy"
    port = 22
    for db_host_info in db_session.query(HostInfo):
        host_ip = db_host_info.host_ip
        try:
            t = paramiko.Transport((host_ip, port))
            t.connect(username=user, password=passwd)
            sftp = paramiko.SFTPClient.from_transport(t)
            remotepath = '/tmp/' + host_ip
            localpath = '/app/info/'+host_ip
            sftp.get(remotepath,localpath)
            t.close()
            logging.info("host "+host_ip+" performance file get success")
            logger_command_return.addHandler(fh_command_return)
            logger_command_return.info("host "+host_ip+" performance file get success")
            logger_command_return.removeHandler(fh_command_return)
        except Exception:
            logging.error("host "+host_ip+" connection error")
            logging.info("host " + host_ip + " performance file get success")
            logger_command_return.addHandler(fh_command_return)
            logger_command_return.info("host "+host_ip+" connection error")
            logger_command_return.removeHandler(fh_command_return)

if __name__ == '__main__':
    get_host_perfor()






