# -*- coding:utf-8 -*-
# from optparse import OptionParser
import argparse
import sys
from vm_start.vm_start import vm_start
from vm_stop.vm_stop import vm_stop
from vm_vnc_address.vm_vnc_address_get import vm_vnc_address_get
from host_std.host_std import host_std
from vm_info.vm_info import vm_info
from host_info.host_info import host_info
from vm_cpu_change.vm_cpu_change import vm_cpu_change
from vm_memory_change.vm_memory_change import vm_memory_change
from host_del.host_del import host_del
from vm_disk_change.vm_disk_change import vm_disk_change
from vm_delete.vm_delete import vm_delete
from vm_migrate.vm_migrate import vm_migrate
from host_pool_list.host_pool_list import host_pool_list

if __name__ == '__main__':
    usage = "sfkvm [positional arguments] -h"
    parser = argparse.ArgumentParser(usage=usage,
                                     description='Introduce: this is tools for kvm host manager, thx!',
                                     version="SF kvm command tools 1.0")
    subparsers = parser.add_subparsers()

    # host pool list module
    host_pool_list_parser = subparsers.add_parser('hostpool',
                                                  help='get kvm host in pool',
                                                  usage='sfkvm hostpool pool_id')
    host_pool_list_parser.add_argument('pool_id',
                                       action='store',
                                       help='which kvm host pool you want to get infomation')

    # host info module
    host_info_parser = subparsers.add_parser('hostinfo',
                                             help='get kvm host information',
                                             usage='sfkvm hostinfo host_ip')
    host_info_parser.add_argument('host_ip',
                                  action='store',
                                  # dest="kvm_ip",
                                  help='which kvm host you want to get infomation')

    # host add module
    host_add_parser = subparsers.add_parser('hostadd',
                                            help='kvm host standardization',
                                            usage='sfkvm hostadd -i host_ip -s host_sn -e env -n net_area')
    host_add_parser.add_argument('-i',
                                 action='store',
                                 dest="host_ip",
                                 help='kvm host ip you want to add')
    host_add_parser.add_argument('-s',
                                 action='store',
                                 dest="sn",
                                 help='kvm host serial number')
    host_add_parser.add_argument('-e',
                                 action='store',
                                 dest="env",
                                 help='kvm host env, like SIT、STG、PRD、DR')
    host_add_parser.add_argument('-n',
                                 action='store',
                                 dest="net_area",
                                 help='kvm host net area, like DCN1、DCN2')

    # host delete module
    host_delete_parser = subparsers.add_parser('hostdel',
                                               help='drop kvm host out of resource pool',
                                               usage='sfkvm hostdel host_ip')
    host_delete_parser.add_argument('host_ip',
                                    action='store',
                                    # dest="host_ip",
                                    help='which kvm host you want to drop out of resource pool')

    # vm info module
    vm_info_parser = subparsers.add_parser('vminfo',
                                           help='get vm information',
                                           usage='sfkvm vminfo vm_name')
    vm_info_parser.add_argument('vm_name',
                                action='store',
                                # dest="vm_hostname",
                                help='which vm you want to get infomation')

    # vm start module
    vm_start_parser = subparsers.add_parser('start',
                                            help='start vm if vm not running',
                                            usage='sfkvm start vm_name')
    vm_start_parser.add_argument('vm_name',
                                 action='store',
                                 # dest="start_hostname",
                                 help='which vm you want to start')

    # vm stop module
    vm_stop_parser = subparsers.add_parser('stop',
                                           help='stop vm if vm running',
                                           usage='sfkvm stop vm_name')
    vm_stop_parser.add_argument('vm_name',
                                action='store',
                                # dest="stop_hostname",
                                help='which vm you want to stop')

    # vm vnc address get module
    vm_vnc_address_get_parser = subparsers.add_parser('vnc_address',
                                                      help='get vnc address for input vm if vm running',
                                                      usage='sfkvm vnc_address vm_name')
    vm_vnc_address_get_parser.add_argument('vm_name',
                                           action='store',
                                           # dest="vnc_hostname",
                                           help='which vm you want to get vnc address')

    # vm memory change module
    vm_memory_change_parser = subparsers.add_parser('vmemchange',
                                                    help='change memory of vm. unit:G',
                                                    usage='sfkvm vmemchange -i vm_name -n number')
    vm_memory_change_parser.add_argument('-n',
                                         action='store',
                                         dest="vm_name",
                                         help='which vm you want to change memory count')

    vm_memory_change_parser.add_argument('-m',
                                         action='store',
                                         dest="memory_count",
                                         help='count of memory you want to change. unit:G')

    # vm cpu change module
    vm_cpu_change_parser = subparsers.add_parser('vcpuchange',
                                                 help='change num of vm cpu',
                                                 usage='sfkvm vcpuchange -i vm_name -n number')
    vm_cpu_change_parser.add_argument('-n',
                                      action='store',
                                      dest="vm_name",
                                      help='which vm you want to change cpu number')

    vm_cpu_change_parser.add_argument('-c',
                                      action='store',
                                      dest="cpu_number",
                                      help='number of vcpu you want to change')

    # vm disk change module
    vm_disk_change_parser = subparsers.add_parser('vdiskchange',
                                                  help='resize vm disk when vm running',
                                                  usage='sfkvm vdiskchange vm_name')
    vm_disk_change_parser.add_argument('-n',
                                       action='store',
                                       dest="vm_name",
                                       help='which vm you want to resize disk')
    vm_disk_change_parser.add_argument('-d',
                                       action='store',
                                       dest="directory",
                                       help='which directory you want to resize, like:/app')
    vm_disk_change_parser.add_argument('--add',
                                       action='store',
                                       dest="size",
                                       help='size to add, unit:G')

    # vm migrate module
    vm_migrate_parser = subparsers.add_parser('migrate',
                                              help='migrate vm from one host to another',
                                              usage='sfkvm migrate -i vm_name -d host_ip')
    vm_migrate_parser.add_argument('-n',
                                   action='store',
                                   dest="vm_name",
                                   help='which vm you want to migrate')

    vm_migrate_parser.add_argument('-d',
                                   action='store',
                                   dest="destination_host",
                                   help='destination host you want vm to migrate')

    # vm delete module
    vm_delete_parser = subparsers.add_parser('vmdel',
                                             help='delete vm if vm not running',
                                             usage='sfkvm vmdel vm_name')
    vm_delete_parser.add_argument('vm_name',
                                  action='store',
                                  # dest="start_hostname",
                                  help='which vm you want to delete')

    result = parser.parse_args()

    module = sys.argv[1]
    # print type(result.net_area)

    env_list = ['SIT', 'STG', 'PRD', 'DR']
    net_area_list = ['DCN1', 'DCN2']

    if module == 'start':
        vm_name = result.vm_name
        msg = vm_start(vm_name)
        print msg
    elif module == 'stop':
        vm_name = result.vm_name
        msg = vm_stop(vm_name)
        print msg
    elif module == 'vnc_address':
        vm_name = result.vm_name
        msg = vm_vnc_address_get(vm_name)
        print msg
    elif module == 'hostadd':
        if not result.host_ip or not result.sn or not result.env or not result.net_area:
            print 'empty input, please check you has input ip and sn and env and net_area'
        elif result.env not in env_list:
            print 'error input, please input SIT or STG or PRD or DR'
        elif result.net_area not in net_area_list:
            print 'error input, please input DCN1 or DCN2'
        else:
            msg = host_std(result.host_ip, result.sn, result.env, result.net_area)
            print msg
    elif module == 'vminfo':
        vm_name = result.vm_name
        vm_info(vm_name)
    elif module == 'hostinfo':
        host_ip = result.host_ip
        host_info(host_ip)
    elif module == 'vcpuchange':
        vm_name = result.vm_name
        vm_cpu_num = result.cpu_number
        if not vm_name or not vm_cpu_num:
            print 'empty input, please check you has input vm hostname and cpu number'
        else:
            msg = vm_cpu_change(vm_name, vm_cpu_num)
            print msg
    elif module == 'vmemchange':
        vm_name = result.vm_name
        vm_memory_num = result.memory_count
        if not vm_name or not vm_memory_num:
            print 'empty input, please check you has input vm hostname and memory count'
        else:
            msg = vm_memory_change(vm_name, vm_memory_num)
            print msg
    elif module == 'hostdel':
        host_ip = result.host_ip
        msg = host_del(host_ip)
        print msg
    elif module == 'vdiskchange':
        vm_name = result.vm_name
        vol_directory = result.directory
        vol_add_size = result.size
        if not vm_name or not vol_directory or not vol_add_size:
            print 'empty input, please check you has input vm hostname and directory and size'
        else:
            msg = vm_disk_change(vm_name, vol_directory, vol_add_size)
            print msg
    elif module == 'vmdel':
        vm_name = result.vm_name
        msg = vm_delete(vm_name)
        print msg
    elif module == 'migrate':
        vm_name = result.vm_name
        dest_kvm_host = result.destination_host
        if not vm_name or not dest_kvm_host:
            print 'empty input, please check you has input vm hostname and memory count'
        else:
            msg = vm_migrate(vm_name, dest_kvm_host)
            print msg
    elif module == 'hostpool':
        pool_id = result.pool_id
        host_pool_list(pool_id)
    else:
        print 'not support module!'



