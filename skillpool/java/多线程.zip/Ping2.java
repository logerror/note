package com.sf.vishnu.proxy.executer.plugin;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sf.vishnu.proxy.dto.ResponseVo;

import net.sf.json.JSONObject;

class pingTask implements Callable<ResponseVo>{
	private Logger log=LoggerFactory.getLogger(PingTest.class);
	private String ip ;
	
	public pingTask() {
	}
	public pingTask(String ip) {
		super();
		this.ip = ip;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	protected ResponseVo executeping(String newip) {
		ResponseVo responseVo = new ResponseVo();
	//	String command = "/bin/ping -c 2 ";
		String command = "ping "+newip;
		Process p=null;
		Runtime proc = null;
		try {
			log.info("ping executor enter in ");
			proc = Runtime.getRuntime();
			p=proc.exec(command);
			p.waitFor();
			if (p.exitValue() != 0) { //ping不通，表示ip可用
				log.info("ping unreached first time, ip is available");
				p = proc.exec(command);
				p.waitFor();
				if(p.exitValue()!=0) {
					log.info("ping unreached sencond time, ip is available");
					responseVo.setResponse("ping unreached sencond time, ip is available\r\n");
					responseVo.setStatus("ok");
				}
			}else{ // ip不可用,ping通了
				log.info("ping tong le, ip is unavailable");
				responseVo.setStatus("fail");
				responseVo.setResponse("ping tong le, ip is unavailable\r\n");
			}
		} catch (IOException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		} catch (InterruptedException e) {
			log.error(e.getMessage(),e);
			responseVo.setStatus("fail");
			responseVo.setError(e.getMessage());
		}
		return responseVo;
	}
	
	@Override
	public ResponseVo call() throws Exception {
		return executeping(ip);
	}	
}

public class Ping2 {
	private static final long serialVersionUID = -538813667700750L;
	protected void myExecute(JSONObject jsonObj, ResponseVo responseVo) throws Throwable{
		String ips = jsonObj.optString("ips");
		if(ips=="") {
			//报错
			System.out.println("传递的ip参数为空");
		}
		int count =0;
		String[] ipa = null  ;
		if(ips.contains(",")) {
			ipa =ips.split(",");
			count=ipa.length;
		}else {
			count=1;
		}
		
		ThreadPoolExecutor tpe = new ThreadPoolExecutor(10, 50, 0, TimeUnit.SECONDS, 
				new LinkedBlockingQueue<Runnable>(), new ThreadPoolExecutor.CallerRunsPolicy());
		List<Future<ResponseVo>> results = new LinkedList<Future<ResponseVo>>();
		
		for(int i=0;i<count;i++) {
			pingTask pingtask = new pingTask(ipa[i]);
			Future<ResponseVo> result= tpe.submit(pingtask);
			results.add(result);
		}
		
		tpe.shutdown();
		System.out.println(tpe.awaitTermination(1, TimeUnit.DAYS));
		System.out.println(new Date());
		for(int i=0;i<count;i++) {
			System.out.println(results.get(i).get());
		}
			
	} 

	public static void main(String[] args) throws Throwable {
		Ping2 ping  = new Ping2();
		JSONObject json = new JSONObject();
		json.put("ips", "10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,"
				+ "10.202.101.23,10.202.101.25,10.202.101.27,10.202.101.31,10.202.101.60,10.202.101.61,10.202.101.23,10.202.101.25,10.202.101.27"
				);
		ResponseVo res = new ResponseVo();
		ping.myExecute(json, res);
		
	}

	
}
