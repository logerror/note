# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from libvirt import libvirtError
from kvm_command_platform.db_table_define import VmInfo
from kvm_command_platform.ansible_operation import ansible_command_get
import time
from kvm_command_platform import log_helper
import logging

db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def vm_delete(vm_name):
    log_handler = log_helper.init_log('vm_delete')
    retryconn = 0
    retry_vol_delete = 0
    succeed_to_conn = False
    succeed_vol_delete = False
    kvm_host = ''
    vm_snapshot_count = 0

    for db_vm_info in db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name):
        kvm_host = db_vm_info.host

    if kvm_host == '':
        db_session.commit()
        db_session.close()
        return 'can not find vm'

    print 'start to connect libvirt:'
    # 使用libvirt操作前先检验可用性
    try:
        conn_test = wvmInstance(kvm_host,
                                'webvirmgr',
                                'sf123456',
                                1,
                                vm_name)
    except libvirtError as err:
        return 'can not connect to libvirt! try delete again'
    # 关闭与libvirt连接
    conn_test.close()
    print 'libvirt connect successful!'

    while retryconn < 3 and not succeed_to_conn:
        try:
            conn = wvmInstance(kvm_host,
                               'webvirmgr',
                               'sf123456',
                               1,
                               vm_name)
            vm_snapshot_count = conn.instance.snapshotNum()
            vm_uuid = conn.get_uuid()
            succeed_to_conn = True
        except libvirtError as err:
            time.sleep(1)
            retryconn += 1

    if retryconn == 3:
        db_session.commit()
        db_session.close()
        return 'can not connect to libvirt'

    if vm_snapshot_count != 0:
        conn.close()
        return 'vm ' + vm_name + ' has snapshot, please delete snapshot and retry delete vm!'

    if conn.get_status() == 1:
        db_session.commit()
        db_session.close()
        conn.close()
        return vm_name + 'is running now, please poweroff first!'
    elif conn.get_status() == 5:
        # 查看虚拟机是否关机超过一天
        print 'start to check vm has been stop exceed one day:'
        command = '/bin/python /root/get_file_mtime.py ' + str(vm_name)
        ansible_kvm_host = [kvm_host]
        ansible_result = ansible_command_get(ansible_kvm_host, command)
        if ansible_result == 1 or ansible_result == 2:
            return 'ansible error, please retry delete or call system manager'
        elif ansible_result[kvm_host]['stderr'] != '':
            return 'ansible error, please retry delete or call system manager'
        elif ansible_result[kvm_host]['stdout'] == '1':
            return 'vm stop less than 1 days, not allow to delete'
        elif ansible_result[kvm_host]['stdout'] == '0':
            vm_all_disk_info = conn.get_delete_disk_device(vm_uuid)
            while retry_vol_delete < 3 and not succeed_vol_delete:
                try:
                    for disk in vm_all_disk_info:
                        stg_pool = disk['storage']
                        stg = conn.get_storage(stg_pool)
                        stg.refresh(0)
                        vol = stg.storageVolLookupByName(disk['image'])
                        print 'start to delete volume ' + str(disk['image'])
                        vol.delete(0)
                        print 'succeed to delete volume ' + str(disk['image'])

                    stg = conn.get_storage(stg_pool)
                    print 'start to stop storage pool ' + str(disk['storage'])
                    stg.destroy()
                    print 'succeed to stop storage pool ' + str(disk['storage'])
                    print 'start to delete storage pool ' + str(disk['storage'])
                    stg.undefine()
                    print 'succeed to delete storage pool ' + str(disk['storage'])
                    conn.delete()
                    print 'start to delete vm ' + str(vm_name) + 'from db'
                    vm_mysql_record = db_session.query(VmInfo).filter(VmInfo.vm_name == vm_name).first()
                    db_session.delete(vm_mysql_record)
                    db_session.commit()
                    db_session.close()
                    print 'succeed to delete vm ' + str(vm_name) + 'from db'
                    succeed_vol_delete = True
                except libvirtError as err:
                    time.sleep(1)
                    retry_vol_delete += 1

            if retry_vol_delete == 3:
                conn.close()
                return 'libvirt error'

        conn.close()
        msg = 'delete all done'
        logging.info(msg)
        return msg
