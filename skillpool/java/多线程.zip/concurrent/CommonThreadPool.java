package concurrent;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonThreadPool {

	private static Logger log = LoggerFactory.getLogger(CommonThreadPool.class);
	private static BlockingQueue<Runnable> jobQueue = new LinkedBlockingQueue<Runnable>(20);  

	private static int  corePoolSize = 3;
	private static int  maximumPoolSize =20;
	private static long  keepAliveTime = 30;
	
	public static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(corePoolSize,
			maximumPoolSize, keepAliveTime, TimeUnit.MILLISECONDS, jobQueue);
	
	public static void execute(Runnable r){
		try {
			threadPoolExecutor.execute(r);
		} catch (RejectedExecutionException ex) {
			log.error(ex.getMessage(), ex);
			throw ex;
		}
	}

	public static void shutdown() {
		threadPoolExecutor.shutdown();
	}
}
