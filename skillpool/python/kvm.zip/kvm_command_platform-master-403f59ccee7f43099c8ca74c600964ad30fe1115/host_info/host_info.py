# -*- coding:utf-8 -*-
# __author__ = '郭思远'

from kvm_command_platform.setting import SQLALCHEMY_DATABASE_URI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from vrtManager.instance import wvmInstance
from kvm_command_platform.db_table_define import HostInfo
import time
from libvirt import libvirtError
import os
import json


db_conn = create_engine(SQLALCHEMY_DATABASE_URI)
session = sessionmaker()
session.configure(bind=db_conn)

db_session = session()


def host_info(host_ip):

    host_sn = ''

    for db_host_info in db_session.query(HostInfo).filter(HostInfo.host_ip == host_ip):
        host_sn = db_host_info.sn
        # 获取物理机机信息，用于展示
        host_env = db_host_info.env
        host_net_area = db_host_info.net_area
        host_host_pool = db_host_info.host_pool

    db_session.commit()
    db_session.close()

    if host_sn == '':
        print 'can not found host ip ' + host_ip
    else:
        # 获取物理机状态信息
        try:
            ftime = os.path.getmtime("/app/info/%s" % host_ip)
            current_time = time.time()
            if (current_time - ftime) > 600:
                # 主机状态文件不是最新返回1值，不执行迁移
                cpu_core = 'unknown'
                mem_size = 'unknown'
                disk_size = 'unknown'
                net_size = 'unknown'
                current_cpu_used = 'unknown'
                current_mem_used = 'unknown'
                current_disk_used = 'unknown'
                week_cpu_p95_used = 'unknown'
                week_mem_p95_used = 'unknown'
                current_net_rx_used = 'unknown'
                current_net_tx_used = 'unknown'

            else:
                with open("/app/info/%s" % host_ip, 'r') as f:
                    data = json.load(f)
                    cpu_core = data['cpu_core']
                    mem_size = data['mem_size'] + ' M'
                    disk_size = data['disk_size'] + ' G'
                    net_size = data['net_size'] + ' Mbit'
                    current_cpu_used = data['current_cpu_used'] + ' %'
                    current_mem_used = data['current_mem_used'] + ' %'
                    current_disk_used = data['current_disk_used'] + ' %'
                    week_cpu_p95_used = data['week_cpu_p95_used'] + ' %'
                    week_mem_p95_used = data['week_mem_p95_used'] + ' %'
                    current_net_rx_used = data['current_net_rx_used'] + ' %'
                    current_net_tx_used = data['current_net_tx_used'] + ' %'
        except:
            # 文件物理机信息不存在，返回1值，不执行迁移
            cpu_core = 'unknown'
            mem_size = 'unknown'
            disk_size = 'unknown'
            net_size = 'unknown'
            current_cpu_used = 'unknown'
            current_mem_used = 'unknown'
            current_disk_used = 'unknown'
            week_cpu_p95_used = 'unknown'
            week_mem_p95_used = 'unknown'
            current_net_rx_used = 'unknown'
            current_net_tx_used = 'unknown'

        print 'ip:                  ' + str(host_ip)
        print 'sn:                  ' + str(host_sn)
        print 'env:                 ' + str(host_env)
        print 'net area:            ' + str(host_net_area)
        print 'host pool:           ' + str(host_host_pool)
        print 'cpu_core:            ' + str(cpu_core)
        print 'mem_size:            ' + str(mem_size)
        print 'disk_size:           ' + str(disk_size)
        print 'net speed:           ' + str(net_size)
        print 'current_cpu_used:    ' + str(current_cpu_used)
        print 'current_mem_used:    ' + str(current_mem_used)
        print 'current_disk_used:   ' + str(current_disk_used)
        print 'week_cpu_p95_used:   ' + str(week_cpu_p95_used)
        print 'week_mem_p95_used:   ' + str(week_mem_p95_used)
        print 'current_net_rx_used: ' + str(current_net_rx_used)
        print 'current_net_tx_used: ' + str(current_net_tx_used)

